# MobeDik
[Mini-projet](https://www.irit.fr/~Georges.Da-Costa/cours/glre/mini_projet.pdf) Android pour l'UE MOBE

Code source sous license GPL
